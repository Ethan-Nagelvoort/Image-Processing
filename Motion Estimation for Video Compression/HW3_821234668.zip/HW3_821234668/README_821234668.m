%Compe 565 - Homework 3: Motion Estimation for Video Compression
%Submission Date: 4/11/2021
%Name: Ethan Nagelvoort
%Red ID: 821234668
%Email: enagelvoort@sdsu.edu

%Homework 3 requires the student to determine the motion vectors of diferent
%frames in a video. This is done by manipulating macroblocks, utulizing the
%exauhsted search method, and SAD. The error image of each P frame is
%obtained and a reconstruction of each P frame is also attained. The frames
%are in IPPPP format so the first frame is used for prediction. To run the
%source code, you will need the walk video. 
